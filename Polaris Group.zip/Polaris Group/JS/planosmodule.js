exports.myplanos = function () {
    return("Planos");
  };