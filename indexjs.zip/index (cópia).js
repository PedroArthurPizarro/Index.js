var http = require('http');

http.createServer(function (req, res) {
  res.writeHead(200, {'Content-Type': 'text/plain'});
  res.end('19/09/2023 Pedro Arthur Pizarro');
}).listen(8012);
